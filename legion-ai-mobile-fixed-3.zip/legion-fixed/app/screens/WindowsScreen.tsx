import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  TouchableOpacity, Modal, TextInput,
} from 'react-native';
import { WebView } from 'react-native-webview';

const DEFAULT_WINDOWS = [
  { id: 1, label: 'Gemini',  url: 'https://gemini.google.com',     active: true },
  { id: 2, label: 'Copilot', url: 'https://copilot.microsoft.com', active: true },
  { id: 3, label: 'Grok',    url: 'https://x.com/i/grok',         active: true },
  { id: 4, label: 'Slot 4',  url: '',                              active: false },
  { id: 5, label: 'Slot 5',  url: '',                              active: false },
  { id: 6, label: 'Slot 6',  url: '',                              active: false },
  { id: 7, label: 'Slot 7',  url: '',                              active: false },
  { id: 8, label: 'Slot 8',  url: '',                              active: false },
];

const AI_PRESETS = [
  { label: 'Gemini',     url: 'https://gemini.google.com' },
  { label: 'Copilot',    url: 'https://copilot.microsoft.com' },
  { label: 'Grok',       url: 'https://x.com/i/grok' },
  { label: 'Claude',     url: 'https://claude.ai' },
  { label: 'ChatGPT',    url: 'https://chat.openai.com' },
  { label: 'DeepSeek',   url: 'https://chat.deepseek.com' },
  { label: 'Perplexity', url: 'https://www.perplexity.ai' },
  { label: 'Suno',       url: 'https://suno.com' },
  { label: 'Pika',       url: 'https://pika.art' },
  { label: 'Runway',     url: 'https://runwayml.com' },
  { label: 'ElevenLabs', url: 'https://elevenlabs.io' },
  { label: 'Custom URL', url: '' },
];

type LegionWindow = { id: number; label: string; url: string; active: boolean };

export default function WindowsScreen() {
  const [windows, setWindows] = useState<LegionWindow[]>(DEFAULT_WINDOWS);
  const [fullscreenId, setFullscreenId] = useState<number | null>(null);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editUrl, setEditUrl] = useState('');
  const [editLabel, setEditLabel] = useState('');

  const activeCount = windows.filter(w => w.active).length;

  const openEdit = (id: number) => {
    const w = windows.find(w => w.id === id)!;
    setEditingId(id);
    setEditUrl(w.url);
    setEditLabel(w.label);
  };

  const saveEdit = () => {
    setWindows(prev => prev.map(w =>
      w.id === editingId
        ? { ...w, url: editUrl, label: editLabel || w.label, active: editUrl.length > 0 }
        : w
    ));
    setEditingId(null);
  };

  const resetWindow = (id: number) => {
    setWindows(prev => prev.map(w =>
      w.id === id ? { ...w, url: '', label: `Slot ${id}`, active: false } : w
    ));
  };

  const fullscreenWindow = windows.find(w => w.id === fullscreenId);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Legion Windows</Text>
        <Text style={styles.headerSub}>{activeCount}/8 active</Text>
      </View>

      <ScrollView contentContainerStyle={styles.grid}>
        {windows.map(win => (
          <View key={win.id} style={[styles.card, !win.active && styles.cardEmpty]}>
            <View style={styles.cardHeader}>
              <View style={[styles.dot, win.active ? styles.dotGreen : styles.dotGrey]} />
              <Text style={styles.cardLabel} numberOfLines={1}>{win.label}</Text>
            </View>
            {win.active && win.url ? (
              <>
                <WebView
                  source={{ uri: win.url }}
                  style={styles.webview}
                  javaScriptEnabled
                  domStorageEnabled
                  onError={() => {}}
                />
                <View style={styles.cardActions}>
                  <TouchableOpacity style={styles.actionBtn} onPress={() => setFullscreenId(win.id)}>
                    <Text style={styles.actionTxt}>Full</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={styles.actionBtn} onPress={() => openEdit(win.id)}>
                    <Text style={styles.actionTxt}>Edit</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={styles.actionBtn} onPress={() => resetWindow(win.id)}>
                    <Text style={[styles.actionTxt, { color: '#e05' }]}>Remove</Text>
                  </TouchableOpacity>
                </View>
              </>
            ) : (
              <TouchableOpacity style={styles.addSlot} onPress={() => openEdit(win.id)}>
                <Text style={styles.addIcon}>+</Text>
                <Text style={styles.addText}>Assign AI</Text>
              </TouchableOpacity>
            )}
          </View>
        ))}
      </ScrollView>

      {/* Fullscreen Modal */}
      <Modal visible={fullscreenId !== null} animationType="slide">
        <View style={styles.fullscreen}>
          <View style={styles.fullscreenBar}>
            <Text style={styles.fullscreenLabel}>{fullscreenWindow?.label}</Text>
            <TouchableOpacity onPress={() => setFullscreenId(null)}>
              <Text style={styles.closeBtn}>Close</Text>
            </TouchableOpacity>
          </View>
          {fullscreenWindow?.url ? (
            <WebView source={{ uri: fullscreenWindow.url }} style={{ flex: 1 }} javaScriptEnabled domStorageEnabled />
          ) : null}
        </View>
      </Modal>

      {/* Edit Modal */}
      <Modal visible={editingId !== null} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalBox}>
            <Text style={styles.modalTitle}>Configure Window {editingId}</Text>
            <Text style={styles.modalLabel}>Label</Text>
            <TextInput style={styles.input} value={editLabel} onChangeText={setEditLabel} placeholder="Window name" placeholderTextColor="#444" />
            <Text style={styles.modalLabel}>Quick Select</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginVertical: 6 }}>
              {AI_PRESETS.map(preset => (
                <TouchableOpacity key={preset.label} style={styles.preset}
                  onPress={() => { setEditUrl(preset.url); if (preset.label !== 'Custom URL') setEditLabel(preset.label); }}>
                  <Text style={styles.presetTxt}>{preset.label}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            <Text style={styles.modalLabel}>URL</Text>
            <TextInput style={styles.input} value={editUrl} onChangeText={setEditUrl} placeholder="https://..." placeholderTextColor="#444" autoCapitalize="none" keyboardType="url" />
            <View style={styles.modalBtns}>
              <TouchableOpacity style={styles.cancelBtn} onPress={() => setEditingId(null)}>
                <Text style={styles.cancelTxt}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.saveBtn} onPress={saveEdit}>
                <Text style={styles.saveTxt}>Save</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0a0f' },
  header: { padding: 16, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', borderBottomWidth: 1, borderBottomColor: '#1a1a2e' },
  headerTitle: { color: '#fff', fontSize: 18, fontWeight: '700' },
  headerSub: { color: '#7b5ea7', fontSize: 14 },
  grid: { padding: 8, flexDirection: 'row', flexWrap: 'wrap', gap: 8, justifyContent: 'center' },
  card: { width: '47%', backgroundColor: '#13131f', borderRadius: 12, borderWidth: 1, borderColor: '#1e1e3a', overflow: 'hidden', minHeight: 180 },
  cardEmpty: { borderStyle: 'dashed', borderColor: '#2a2a3a' },
  cardHeader: { flexDirection: 'row', alignItems: 'center', padding: 8, gap: 6, backgroundColor: '#0d0d18' },
  dot: { width: 7, height: 7, borderRadius: 4 },
  dotGreen: { backgroundColor: '#44ee88' },
  dotGrey: { backgroundColor: '#333' },
  cardLabel: { color: '#ccc', fontSize: 12, fontWeight: '700', flex: 1 },
  webview: { height: 120 },
  cardActions: { flexDirection: 'row', justifyContent: 'space-around', padding: 6, backgroundColor: '#0d0d18' },
  actionBtn: { paddingHorizontal: 8, paddingVertical: 4 },
  actionTxt: { color: '#7b5ea7', fontSize: 11, fontWeight: '700' },
  addSlot: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 20 },
  addIcon: { color: '#2a2a4a', fontSize: 32 },
  addText: { color: '#333', fontSize: 12, marginTop: 4 },
  fullscreen: { flex: 1, backgroundColor: '#000' },
  fullscreenBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 14, backgroundColor: '#0d0d18' },
  fullscreenLabel: { color: '#fff', fontSize: 16, fontWeight: '700' },
  closeBtn: { color: '#7b5ea7', fontSize: 14, fontWeight: '700' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.8)', justifyContent: 'flex-end' },
  modalBox: { backgroundColor: '#13131f', borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20 },
  modalTitle: { color: '#fff', fontSize: 17, fontWeight: '700', marginBottom: 16 },
  modalLabel: { color: '#777', fontSize: 12, fontWeight: '600', marginBottom: 6, marginTop: 12 },
  input: { backgroundColor: '#0a0a0f', borderWidth: 1, borderColor: '#2a2a3a', borderRadius: 10, padding: 12, color: '#fff', fontSize: 14 },
  preset: { backgroundColor: '#1e1e3a', borderRadius: 8, paddingHorizontal: 12, paddingVertical: 8, marginRight: 8 },
  presetTxt: { color: '#a0a0ff', fontSize: 12, fontWeight: '600' },
  modalBtns: { flexDirection: 'row', gap: 10, marginTop: 20 },
  cancelBtn: { flex: 1, padding: 14, borderRadius: 10, borderWidth: 1, borderColor: '#2a2a3a', alignItems: 'center' },
  cancelTxt: { color: '#888', fontWeight: '700' },
  saveBtn: { flex: 1, padding: 14, borderRadius: 10, backgroundColor: '#7b5ea7', alignItems: 'center' },
  saveTxt: { color: '#fff', fontWeight: '700' },
});
